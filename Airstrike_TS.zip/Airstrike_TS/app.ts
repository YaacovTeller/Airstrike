﻿type Status = {
    moving,
    pausing,
}
type Weapon = {
    blastRadius: number,
    speed: number,
    blastPower: number,
    cursor: string,
    sound: Array<Sound>,
    cooldown: number,
    ready: boolean
}
const sniper: Weapon = {
    blastRadius: 15,
    speed: 0,
    blastPower: 0,
    cursor: ".cursor1",
    sound: [],
    cooldown: 0,
    ready: true
}
const mortar: Weapon = {
    blastRadius: 50,
    speed: 2000,
    blastPower: 5,
    cursor: ".cursor2",
    sound: mortarSounds,
    cooldown: 1,
    ready: true
}
const howitzer: Weapon = {
    blastRadius: 70,
    speed: 3000,
    blastPower: 5,
    cursor: ".cursor2",
    sound: howitzerSounds,
    cooldown: 2,
    ready: true
}
const airStrike: Weapon = {
    blastRadius: 100,
    speed: 4000,
    blastPower: 10,
    cursor: ".cursor3",
    sound: airstrikeSounds,
    cooldown: 4,
    ready: true
}

const assetsFolder: string = "./AS_assets/"

function getRandom(low: number, high: number) {
    return Math.floor(Math.random() * high) + low;
}
class Target {
    private contentEl: HTMLElement;
    private targetEl: HTMLElement;
    private picEl: HTMLImageElement;

    private speed: number;
    private picSource: string = assetsFolder + 'jeep.png';
    private destroyedSource: string = assetsFolder + 'fire.gif';
    private active: Boolean = true;
    private startPosition: number;

    constructor(contentEl: HTMLElement) {
        this.contentEl = contentEl; // ????? don't pass down?
        this.speed = getRandom(1, 8);
        this.startPosition = getRandom(10, 90);

        this.targetEl = document.createElement("div");
        this.picEl = document.createElement("img");
        this.picEl.src = this.picSource;
        this.targetEl.classList.add('target');
        this.targetEl.appendChild(this.picEl);
        this.targetEl.style.top = this.startPosition + '%';
        this.targetEl.style.left = 0 + 'px';
        contentEl.appendChild(this.targetEl);
    }
    private move() {
        this.targetEl.style.left = parseInt(this.targetEl.style.left) + this.speed + "px";
    }
    public checkPos(blastRadiusEl: HTMLElement) {
        var rect = this.targetEl.getBoundingClientRect();
        var blast = blastRadiusEl.getBoundingClientRect();

        //var blastX = blast.left + blast.width / 2;
        //var blastY = blast.top + blast.height / 2;
        var centerX = rect.left + rect.width / 2;
        var centerY = rect.top + rect.height / 2;

        if (centerX >= blast.left &&
            centerX <= blast.left + blast.width &&
            centerY >= blast.top &&
            centerY <= blast.top + blast.height) {

            return true
        }
        else return false
    }

    //public checkPos(event: MouseEvent, blastRadius: number) {
    //    var rect = this.targetEl.getBoundingClientRect();

    //    let mouseX = event.clientX;
    //    let mouseY = event.clientY;
    //    var centerX = rect.left + rect.width / 2;
    //    var centerY = rect.top + rect.height / 2;

    //    if (centerX + blastRadius >= mouseX &&
    //        centerX - blastRadius <= mouseX &&
    //        centerY + blastRadius >= mouseY &&
    //        centerY - blastRadius <=  mouseY) {

    //        return true
    //    }
    //    else return false
    //}

    public hit() {
        this.active = false;
        this.picEl.src = this.destroyedSource;
    }

    public action() {
        if (this.active == true) {

            this.move();
        }
    }
}
type mousePos = {
    mouseX,
    mouseY
}

class TargetHandler {
    private targets: Array<Target> = [];
    private contentEl: HTMLElement;
    private blastRadiusEl: HTMLElement;
    private explosion: HTMLImageElement;
    private explosionSource: string = assetsFolder + 'expl.gif';
    //private explosionSource: string = assetsFolder + 'nuclear.gif';

    private weapon: Weapon;
    private targetTimer: number;
    private gameTimer: number;
    private firing: boolean = false;
    private mousePos: mousePos = { mouseX:"", mouseY:""};

    constructor(element: HTMLElement) {
        this.contentEl = element;
        this.blastRadiusEl = document.createElement('div');
        this.blastRadiusEl.classList.add('blastRadius');
        this.contentEl.appendChild(this.blastRadiusEl);
        this.explosion = document.createElement('img');
        this.explosion.classList.add('explosion');
        this.explosion.src = this.explosionSource;
        this.contentEl.appendChild(this.explosion);
        this.switchBlastIndicatorStyle(false);

        this.contentEl.addEventListener("click", (event) => this.fireFunc(event));
        this.contentEl.addEventListener('mousemove', (event) => this.updateCursorPosition(event));
        window.addEventListener('keydown', (event) => this.handleKeyPress(event), true);
        this.changeWeapon(mortar);
    }

    private switchBlastIndicatorStyle(bool: boolean) {
        if (bool) {
            this.blastRadiusEl.classList.remove("preFire");
            this.blastRadiusEl.classList.add("firing");
        }
        else {
            this.blastRadiusEl.classList.add("preFire");
            this.blastRadiusEl.classList.remove("firing");
        }
    }
    private handleKeyPress(event) {
         if (event.key === '2') { this.changeWeapon(mortar) }
        else if (event.key === '3') { this.changeWeapon(howitzer) }
        else if (event.key === '4') { this.changeWeapon(airStrike) }
     // else if (event.key === '1') { this.changeWeapon(sniper) }
    }
    private updateCursorPosition(event?: MouseEvent) {
        let x;
        let y;
        if (event) {
            x = this.mousePos.mouseX = event.clientX
            y = this.mousePos.mouseY = event.clientY
        }
        else {
            x = this.mousePos.mouseX;
            y = this.mousePos.mouseY;
        }

        if (this.firing) return;

        this.blastRadiusEl.style.left = x - this.blastRadiusEl.offsetWidth / 2 + 'px';
        this.blastRadiusEl.style.top = y - this.blastRadiusEl.offsetHeight / 2 + 'px';
    }
    private changeWeapon(wep: Weapon) {
        this.weapon = wep;
        this.blastRadiusEl.style.width = this.blastRadiusEl.style.height = this.weapon.blastRadius * 2 + 'px';

        this.contentEl.classList.forEach((className) => {
            className.startsWith('cursor') ? this.contentEl.classList.remove(className) : "";
        })
        this.contentEl.classList.add(this.weapon.cursor)
    }

    private prepFire(bool: boolean) {
        this.firing = bool;
        this.weapon.ready = !bool;
        this.switchBlastIndicatorStyle(bool);
        if (bool) {
            this.rippleEffect();
            RandomSoundGen.playRandomSound(this.weapon.sound);
        }
        if (!bool) {
            this.updateCursorPosition();
        }
    }
    private bonusHitSound() {
        RandomNumberGen.randomNumBetween(1, 8) == 8 ? pgia.play() : "";
    }
    private explosion_targetCheck() {
        this.explosion.style.visibility = 'visible';

        setTimeout(() => {
            this.explosion.style.visibility = 'hidden';
        }, 1000)

        for (let target of this.targets) {
            if (target.checkPos(this.blastRadiusEl)) {
                target.hit();
                this.bonusHitSound();
            }
        }
    }

    private fireFunc(event: MouseEvent) {
        if (this.weapon.ready == false) { return }
        this.prepFire(true);
        var blastRect = this.blastRadiusEl.getBoundingClientRect();

        var blastX = blastRect.left + blastRect.width / 2;
        var blastY = blastRect.top + blastRect.height / 2;

        this.explosion.style.width = blastRect.width + 'px';
        this.explosion.style.height = blastRect.height + 'px';
        this.explosion.style.top = blastY - this.explosion.clientHeight * 0.9 + 'px';
        this.explosion.style.left = blastX - this.explosion.clientWidth / 2 + 'px';

        setTimeout(() => {
            this.explosion_targetCheck();
            this.prepFire(false);
        }, this.weapon.speed)
    }
    private rippleEffect() {
        const circle = document.createElement("span");
        const diameter = this.blastRadiusEl.clientWidth;

        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = this.blastRadiusEl.clientLeft + 'px';
        circle.style.top = this.blastRadiusEl.clientTop + 'px';
        circle.classList.add("ripple");

        const ripple = this.blastRadiusEl.getElementsByClassName("ripple")[0];
        ripple ? ripple.remove() : () => { };

        this.blastRadiusEl.appendChild(circle);
    }

    public newTarget() {
        let newTarget = new Target(this.contentEl);
        this.targets.push(newTarget)
    }

    public start() {
        this.targetTimer = window.setInterval(() => {
            this.newTarget();

        }, 3000);
        this.gameTimer = window.setInterval(() => {
            this.targets.forEach((trg) => {
                trg.action();
            })
        }, 100);
    }
}

class RandomNumberGen {
    static randomNumBetween(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}

window.onload = () => {
    const el: HTMLElement = document.getElementById("content")!;
    loadSound();
    const game = new TargetHandler(el);
    game.start();
};