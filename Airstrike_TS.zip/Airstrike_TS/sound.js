class Sound {
    sound;
    title;
    constructor(src) {
        let arr = src.split('/');
        this.title = arr[arr.length - 2] + "/" + arr[arr.length - 1];
        this.sound = document.createElement("audio");
        this.sound.src = src;
        this.sound.setAttribute("preload", "auto");
        this.sound.setAttribute("controls", "none");
        document.body.appendChild(this.sound);
    }
    setVolume(vol) {
        this.sound.volume = vol;
    }
    play() {
        this.sound.play();
    }
    stop() {
        this.sound.pause();
    }
    playClone() {
        this.sound.cloneNode(true).play();
    }
}
class RandomSoundGen {
    soundIndex = 0;
    static getRandomSound(sounds) {
        let length = sounds.length;
        let randNum = Math.floor(Math.random() * (length) + 1);
        return sounds[randNum - 1];
    }
    static playRandomSound(sounds) {
        let sound = this.getRandomSound(sounds);
        sound.play();
    }
    playNotSoRandomSound(sounds) {
        if (this.soundIndex == sounds.length - 1) {
            this.soundIndex = 0;
        }
        else
            this.soundIndex++;
        sounds[this.soundIndex].play();
    }
}
const soundFolder = "./AS_assets/sound/";
var mortarSounds = [];
var howitzerSounds = [];
var airstrikeSounds = [];
var pgia;
function loadSound() {
    pgia = new Sound(soundFolder + "pgia.mp3");
    mortarSounds.push(new Sound(soundFolder + "mortar_1.mp3"), new Sound(soundFolder + "mortar_2.mp3"), new Sound(soundFolder + "mortar_3.mp3"), new Sound(soundFolder + "mortar_4.mp3"), new Sound(soundFolder + "mortar_5.mp3"));
    howitzerSounds.push(new Sound(soundFolder + "yoRE_1.mp3"), new Sound(soundFolder + "yoRE_2.mp3"), new Sound(soundFolder + "yoRE_3.mp3"));
    airstrikeSounds.push(new Sound(soundFolder + "shager_1.mp3"), new Sound(soundFolder + "shager_2.mp3"), new Sound(soundFolder + "shager_3.mp3"), new Sound(soundFolder + "shager_4.mp3"), new Sound(soundFolder + "shager_5.mp3"));
}
//mortar_1 = new Sound(soundFolder + "mortar_1.mp3")
//mortar_2 = new Sound(soundFolder + "mortar_2.mp3")
//mortar_3 = new Sound(soundFolder + "mortar_3.mp3")
//mortar_4 = new Sound(soundFolder + "mortar_4.mp3")
//mortar_5 = new Sound(soundFolder + "mortar_5.mp3")
//    )
//var yoRE_1 = new Sound(soundFolder + "yoRE_1.mp3");
//var yoRE_2 = new Sound(soundFolder + "yoRE_2.mp3");
//var yoRE_3 = new Sound(soundFolder + "yoRE_3.mp3");
////var yoRE_4 = new Sound(soundFolder + "yoRE_4.mp3");
////var yoRE_5 = new Sound(soundFolder + "yoRE_5.mp3");
//var shager_1 = new Sound(soundFolder + "shager_1.mp3");
//var shager_2 = new Sound(soundFolder + "shager_2.mp3");
//var shager_3 = new Sound(soundFolder + "shager_3.mp3");
//    //var shager_4 = new Sound(soundFolder + "shager_4.mp3");
//    //var shager_5 = new Sound(soundFolder + "shager_5.mp3");
//# sourceMappingURL=sound.js.map