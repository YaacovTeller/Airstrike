class Target {
    targetEl;
    picEl;
    speed;
    picSource = assetsFolder + 'jeep.png';
    destroyedSource = assetsFolder + 'fire.gif';
    startPosition;
    active = true;
    constructor(contentEl) {
        this.speed = getRandom(1, 8);
        this.startPosition = getRandom(10, 90);
        this.targetEl = document.createElement("div");
        this.picEl = document.createElement("img");
        this.picEl.src = this.picSource;
        this.targetEl.classList.add('target');
        this.targetEl.appendChild(this.picEl);
        this.targetEl.style.top = window.innerHeight * this.startPosition / 100 + 'px';
        this.targetEl.style.left = 0 + 'px';
        contentEl.appendChild(this.targetEl);
    }
    move() {
        this.targetEl.style.left = parseInt(this.targetEl.style.left) + this.speed + "px";
    }
    getTargetEl() {
        return this.targetEl;
    }
    hit() {
        this.active = false;
        this.picEl.src = this.destroyedSource;
        this.picEl.classList.add('destroyed');
    }
    action() {
        if (this.active == true) {
            this.move();
        }
    }
}
//# sourceMappingURL=Target.js.map