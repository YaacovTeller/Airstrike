const assetsFolder = "./AS_assets/";
var weaponNames;
(function (weaponNames) {
    weaponNames["gun"] = "gun";
    weaponNames["mortar"] = "mortar";
    weaponNames["howitzer"] = "howitzer";
    weaponNames["airstrike"] = "airstrike";
    weaponNames["nuke"] = "nuke";
})(weaponNames || (weaponNames = {}));
const sniperInfo = {
    name: weaponNames.gun,
    blastRadius: 6,
    speed: 0,
    blastPower: 0,
    cursor: "cursor1",
    explosionSource: "",
    imageSource: assetsFolder + 'gun.svg',
    sound: gunSounds,
    cooldown: 0,
    instances: [],
};
const mortarInfo = {
    name: weaponNames.mortar,
    blastRadius: 50,
    speed: 2000,
    blastPower: 5,
    cursor: "cursor2",
    explosionSource: assetsFolder + 'expl.gif',
    imageSource: assetsFolder + 'mortar.svg',
    sound: mortarSounds,
    cooldown: 1,
    instances: [],
};
const howitzerInfo = {
    name: weaponNames.howitzer,
    blastRadius: 70,
    speed: 3000,
    blastPower: 5,
    cursor: "cursor3",
    explosionSource: assetsFolder + 'expl.gif',
    imageSource: assetsFolder + 'tank.svg',
    sound: howitzerSounds,
    cooldown: 2,
    instances: [],
};
const airstrikeInfo = {
    name: weaponNames.airstrike,
    blastRadius: 100,
    speed: 4000,
    blastPower: 10,
    cursor: "cursor4",
    explosionSource: assetsFolder + 'expl.gif',
    imageSource: assetsFolder + 'jet.svg',
    sound: airstrikeSounds,
    cooldown: 4,
    instances: [],
};
const nukeInfo = {
    name: weaponNames.nuke,
    blastRadius: 400,
    speed: 6000,
    blastPower: 10,
    cursor: "cursor4",
    explosionSource: assetsFolder + 'expl.gif',
    imageSource: assetsFolder + 'bomb.svg',
    sound: nukeSounds,
    cooldown: 15,
    instances: [],
};
class HudHandler {
    hud;
    selectedWep;
    drawHUD() {
        let hud = document.getElementById('hud');
        if (hud)
            hud.remove();
        let el = document.createElement('div');
        el.classList.add("hud");
        el.id = 'hud';
        addToContentEl(el);
        this.hud = el;
        for (let x of allWeaponTypes) {
            let wepBox = document.createElement('div');
            wepBox.classList.add("wepBox");
            wepBox.dataset.name = x.name;
            wepBox.style.backgroundImage = "url(" + x.imageSource + ")";
            el.appendChild(wepBox);
            for (let y of x.instances) {
                let instBox = document.createElement('div');
                instBox.classList.add("instBox");
                wepBox.appendChild(instBox);
            }
        }
    }
    selectBox(wepName) {
        let weps = this.hud.getElementsByClassName('wepBox');
        for (let x of weps) {
            if (x.getAttribute('data-name') == wepName) {
                x.classList.add("selected");
                this.selectedWep = x;
            }
            else
                x.classList.remove("selected");
        }
    }
    selectInst() {
        let insts = this.selectedWep.getElementsByClassName('instBox');
        for (let x of insts) {
        }
    }
}
class WeaponType {
    name;
    blastRadius;
    speed;
    blastPower;
    cursor;
    sound;
    cooldown;
    instances = [];
    activeInstance;
    explosionSource;
    imageSource;
    constructor(info) {
        this.name = info.name;
        this.blastRadius = info.blastRadius;
        this.blastPower = info.blastPower;
        this.speed = info.speed;
        this.cursor = info.cursor;
        this.sound = info.sound;
        this.cooldown = info.cooldown;
        this.explosionSource = info.explosionSource;
        this.imageSource = info.imageSource;
        this.pushNewWeaponInstance();
    }
    switchTo() {
        this.activeInstance = this.getAvailableInstance();
    }
    pushNewWeaponInstance() {
        let el = document.createElement('div');
        el.classList.add('blastRadius');
        el.classList.add('preFire');
        this.name == weaponNames.nuke ? el.classList.add('nukeIndicator') : "";
        el.classList.add('circle' + this.instances.length);
        el.style.width = el.style.height = this.blastRadius * 2 + 'px';
        el.style.visibility = "hidden";
        let explosion = document.createElement('img');
        explosion.classList.add('explosion');
        var timestamp = new Date().getTime();
        explosion.src = this.explosionSource + '?' + timestamp;
        addToContentEl(explosion);
        if (this.name == weaponNames.nuke) {
        }
        let inst = {
            ready: true,
            blastRadElement: el,
            explosion
        };
        this.instances.push(inst);
        addToContentEl(el);
    }
    getAvailableInstance() {
        let current = this.activeInstance;
        let nextReady = this.instances.find(inst => inst.ready == true) || null;
        if (nextReady != null) {
            nextReady.blastRadElement.style.visibility = "visible";
        }
        //    nextReady === current ? console.log("SAME!") : console.log("DIFF!")
        return nextReady;
    }
    fireFunc(targets) {
        if (this.activeInstance == null) {
            console.log("hit NULL inst");
            return;
        }
        let inst = this.activeInstance;
        let blastRadiusEl = inst.blastRadElement;
        this.prepFire(true, inst);
        let explosion = inst.explosion;
        let blastRect = blastRadiusEl.getBoundingClientRect();
        explosion.style.width = blastRect.width + 'px';
        explosion.style.height = blastRect.height + 'px';
        let blastCenter = CollisionDetection.getXYfromPoint(blastRadiusEl);
        explosion.style.left = blastCenter.X - explosion.clientWidth / 2 + 'px';
        explosion.style.top = blastCenter.Y - explosion.clientHeight * 0.9 + 'px';
        this.activeInstance = this.getAvailableInstance();
        setTimeout(() => {
            this.explosion_targetCheck(targets, inst);
            this.prepFire(false, inst);
            inst.ready = true;
            this.activeInstance = this.activeInstance == null ? this.getAvailableInstance() : this.activeInstance;
        }, this.speed);
    }
    explosion_targetCheck(targets, inst) {
        let explosion = inst.explosion;
        explosion.style.visibility = 'visible';
        setTimeout(() => {
            explosion.style.visibility = 'hidden';
        }, 1000);
        for (let target of targets) {
            let collisionInfo = CollisionDetection.checkPos(inst.blastRadElement, target.getTargetEl());
            if (collisionInfo) {
                let destroy = this.name != weaponNames.gun ? true : false;
                destroy ? CollisionDetection.moveAtAngle(collisionInfo) : "";
                if (!target.destroyed) {
                    target.hit(destroy);
                    this.bonusHitSound();
                }
            }
        }
    }
    prepFire(bool, inst) {
        this.switchBlastIndicatorStyle(bool, inst);
        if (bool) {
            this.rippleEffect(inst);
            RandomSoundGen.playNotSoRandomSound(this.sound);
            if (this.name == weaponNames.airstrike) {
                setTimeout(() => strike.play(), 2500);
            }
            if (this.name == weaponNames.nuke) {
                setTimeout(() => bigExpl.play(), 6500);
            }
        }
        inst.ready = !bool;
    }
    switchBlastIndicatorStyle(bool, inst) {
        if (inst == null)
            return;
        let blastRadiusEl = inst.blastRadElement;
        if (bool) {
            blastRadiusEl.classList.remove("preFire");
            blastRadiusEl.classList.add("firing");
        }
        else {
            blastRadiusEl.classList.add("preFire");
            blastRadiusEl.classList.remove("firing");
        }
    }
    rippleEffect(inst) {
        let blastRadiusEl = inst.blastRadElement;
        const circle = document.createElement("span");
        const diameter = blastRadiusEl.clientWidth;
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = blastRadiusEl.clientLeft + 'px';
        circle.style.top = blastRadiusEl.clientTop + 'px';
        circle.classList.add("ripple");
        const ripple = blastRadiusEl.getElementsByClassName("ripple")[0];
        ripple ? ripple.remove() : () => { };
        blastRadiusEl.appendChild(circle);
    }
    bonusHitSound() {
        RandomNumberGen.randomNumBetween(1, 8) == 8 ? pgia.play() : "";
    }
}
function addToContentEl(elem) {
    let contentEl = document.getElementById("content");
    contentEl.appendChild(elem);
}
function getRandom(low, high) {
    return Math.floor(Math.random() * high) + low;
}
class TargetHandler {
    targets = [];
    contentEl;
    hud = new HudHandler();
    targetTimer;
    gameTimer;
    weapon;
    constructor(element) {
        this.contentEl = element;
        this.contentEl.addEventListener("click", (event) => this.fireFunc());
        this.contentEl.addEventListener('mousemove', (event) => this.updateCursorPosition(event));
        window.addEventListener('keydown', (event) => this.handleKeyPress(event), true);
        this.hud.drawHUD();
        this.changeWeapon(mortar);
        this.weapon.switchBlastIndicatorStyle(false, null);
    }
    fireFunc() {
        this.weapon.fireFunc(this.targets);
    }
    handleKeyPress(event) {
        if (event.key === '1') {
            this.changeWeapon(sniper);
        }
        else if (event.key === '2') {
            this.changeWeapon(mortar);
        }
        else if (event.key === '3') {
            this.changeWeapon(howitzer);
        }
        else if (event.key === '4') {
            this.changeWeapon(airstrike);
        }
        else if (event.key === '5') {
            this.changeWeapon(nuke);
        }
        else if (event.shiftKey && event.key === 'N') {
            this.addNuke();
        }
    }
    updateCursorPosition(event) {
        let newMousePos = MouseHandler.updateMousePos(event);
        if (this.weapon.activeInstance) {
            let blast = this.weapon.activeInstance.blastRadElement;
            this.positionElem(blast, newMousePos);
        }
    }
    positionElem(elem, pos) {
        elem.style.left = pos.X - elem.offsetWidth / 2 + 'px';
        elem.style.top = pos.Y - elem.offsetHeight / 2 + 'px';
    }
    changeWeapon(wep) {
        if (!allWeaponTypes.includes(wep))
            return;
        this.weapon = wep;
        this.weapon.switchTo();
        let inst = this.weapon.getAvailableInstance();
        if (inst) {
            this.weapon.switchBlastIndicatorStyle(false, inst);
        }
        this.switchCursor();
        this.updateCursorPosition();
        allWeaponTypes.forEach((x) => {
            if (x !== wep) {
                if (x.instances.length && x.activeInstance) {
                    if (x.activeInstance.ready != false) {
                        x.instances.forEach((inst) => { inst.blastRadElement.style.visibility = "hidden"; });
                    }
                }
            }
        });
        this.hud.selectBox(wep.name);
    }
    switchCursor() {
        this.contentEl.classList.forEach((className) => {
            className.startsWith('cursor') ? this.contentEl.classList.remove(className) : "";
        });
        this.contentEl.classList.add(this.weapon.cursor);
    }
    newTarget() {
        let newTarget = new Target(this.contentEl);
        this.targets.push(newTarget);
    }
    addNuke() {
        nuke = new WeaponType(nukeInfo);
        allWeaponTypes.push(nuke);
        this.hud.drawHUD();
    }
    start() {
        this.targetTimer = window.setInterval(() => {
            this.newTarget();
        }, 3000);
        this.gameTimer = window.setInterval(() => {
            this.targets.forEach((trg) => {
                trg.action();
            });
        }, 100);
    }
}
class MouseHandler {
    static mousePos = { X: '', Y: '' };
    static updateMousePos(event) {
        if (event) {
            this.mousePos.X = event.clientX;
            this.mousePos.Y = event.clientY;
        }
        return this.mousePos;
    }
}
class RandomNumberGen {
    static randomNumBetween(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}
var sniper;
var mortar;
var howitzer;
var airstrike;
var nuke;
var allWeaponTypes;
window.onload = () => {
    const contentEl = document.getElementById("content");
    sniper = new WeaponType(sniperInfo);
    mortar = new WeaponType(mortarInfo);
    howitzer = new WeaponType(howitzerInfo);
    airstrike = new WeaponType(airstrikeInfo);
    allWeaponTypes = [sniper, mortar, howitzer, airstrike];
    mortar.pushNewWeaponInstance();
    mortar.pushNewWeaponInstance();
    const game = new TargetHandler(contentEl);
    loadSound();
    game.start();
};
//# sourceMappingURL=app.js.map