const assetsFolder = "./AS_assets/";
const sniperInfo = {
    blastRadius: 15,
    speed: 0,
    blastPower: 0,
    cursor: "cursor1",
    explosionSource: "",
    sound: [],
    cooldown: 0,
    instances: [],
};
const mortarInfo = {
    blastRadius: 50,
    speed: 2000,
    blastPower: 5,
    cursor: "cursor2",
    explosionSource: assetsFolder + 'expl.gif',
    sound: mortarSounds,
    cooldown: 1,
    instances: [],
};
const howitzerInfo = {
    blastRadius: 70,
    speed: 3000,
    blastPower: 5,
    cursor: "cursor3",
    explosionSource: assetsFolder + 'expl.gif',
    sound: howitzerSounds,
    cooldown: 2,
    instances: [],
};
const airstrikeInfo = {
    blastRadius: 100,
    speed: 4000,
    blastPower: 10,
    cursor: "cursor4",
    explosionSource: assetsFolder + 'expl.gif',
    sound: airstrikeSounds,
    cooldown: 4,
    instances: [],
};
class WeaponType {
    blastRadius;
    speed;
    blastPower;
    cursor;
    sound;
    cooldown;
    instances = [];
    activeInstance;
    explosionSource;
    constructor(info) {
        this.blastRadius = info.blastRadius;
        this.blastPower = info.blastPower;
        this.speed = info.speed;
        this.cursor = info.cursor;
        this.sound = info.sound;
        this.cooldown = info.cooldown;
        this.explosionSource = info.explosionSource;
        this.pushNewWeaponInstance();
        this.activeInstance = this.getAvailableInstance();
    }
    pushNewWeaponInstance() {
        let el = document.createElement('div');
        el.classList.add('blastRadius');
        el.classList.add('preFire');
        el.classList.add('circle' + this.instances.length);
        el.style.width = el.style.height = this.blastRadius * 2 + 'px';
        el.style.visibility = "hidden";
        let explosion = document.createElement('img');
        explosion.classList.add('explosion');
        var timestamp = new Date().getTime();
        explosion.src = this.explosionSource + '?' + timestamp;
        addToContentEl(explosion);
        let inst = {
            ready: true,
            blastRadElement: el,
            explosion
        };
        this.instances.push(inst);
        addToContentEl(el);
    }
    getAvailableInstance() {
        let current = this.activeInstance;
        let nextReady = this.instances.find(inst => inst.ready == true) || null;
        if (nextReady != null) {
            nextReady.blastRadElement.style.visibility = "visible";
        }
        //    nextReady === current ? console.log("SAME!") : console.log("DIFF!")
        return nextReady;
    }
    explosion_targetCheck(targets, inst) {
        let explosion = inst.explosion;
        explosion.style.visibility = 'visible';
        console.log("visilized explosion");
        setTimeout(() => {
            explosion.style.visibility = 'hidden';
        }, 1000);
        for (let target of targets) {
            if (CollisionDetection.checkPos(inst.blastRadElement, target.getTargetEl())) {
                if (target.active) {
                    target.hit();
                    this.bonusHitSound();
                }
            }
        }
    }
    fireFunc(targets) {
        if (this.activeInstance == null) {
            console.log("hit NULL inst");
            return;
        }
        let inst = this.activeInstance;
        let blastRadiusEl = inst.blastRadElement;
        this.prepFire(true, inst);
        let explosion = inst.explosion;
        let blastRect = blastRadiusEl.getBoundingClientRect();
        explosion.style.width = blastRect.width + 'px';
        explosion.style.height = blastRect.height + 'px';
        let blastCenter = CollisionDetection.getXYfromPoint(blastRadiusEl);
        explosion.style.left = blastCenter.X - explosion.clientWidth / 2 + 'px';
        explosion.style.top = blastCenter.Y - explosion.clientHeight * 0.9 + 'px';
        this.activeInstance = this.getAvailableInstance();
        setTimeout(() => {
            this.explosion_targetCheck(targets, inst);
            this.prepFire(false, inst);
            inst.ready = true;
            this.activeInstance = this.activeInstance == null ? this.getAvailableInstance() : this.activeInstance;
        }, this.speed);
    }
    prepFire(bool, inst) {
        this.switchBlastIndicatorStyle(bool, inst);
        if (bool) {
            this.rippleEffect(inst);
            RandomSoundGen.playNotSoRandomSound(this.sound);
        }
        inst.ready = !bool;
    }
    switchBlastIndicatorStyle(bool, inst) {
        if (inst == null)
            return;
        let blastRadiusEl = inst.blastRadElement;
        if (bool) {
            blastRadiusEl.classList.remove("preFire");
            blastRadiusEl.classList.add("firing");
        }
        else {
            blastRadiusEl.classList.add("preFire");
            blastRadiusEl.classList.remove("firing");
        }
    }
    rippleEffect(inst) {
        let blastRadiusEl = inst.blastRadElement;
        const circle = document.createElement("span");
        const diameter = blastRadiusEl.clientWidth;
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = blastRadiusEl.clientLeft + 'px';
        circle.style.top = blastRadiusEl.clientTop + 'px';
        circle.classList.add("ripple");
        const ripple = blastRadiusEl.getElementsByClassName("ripple")[0];
        ripple ? ripple.remove() : () => { };
        blastRadiusEl.appendChild(circle);
    }
    bonusHitSound() {
        RandomNumberGen.randomNumBetween(1, 8) == 8 ? pgia.play() : "";
    }
}
function addToContentEl(elem) {
    let contentEl = document.getElementById("content");
    contentEl.appendChild(elem);
}
function getRandom(low, high) {
    return Math.floor(Math.random() * high) + low;
}
class TargetHandler {
    targets = [];
    contentEl;
    targetTimer;
    gameTimer;
    weapon;
    constructor(element) {
        this.contentEl = element;
        this.contentEl.addEventListener("click", (event) => this.fireFunc());
        this.contentEl.addEventListener('mousemove', (event) => this.updateCursorPosition(event));
        window.addEventListener('keydown', (event) => this.handleKeyPress(event), true);
        this.changeWeapon(mortar);
        this.weapon.switchBlastIndicatorStyle(false, null);
    }
    fireFunc() {
        this.weapon.fireFunc(this.targets);
    }
    handleKeyPress(event) {
        if (event.key === '2') {
            this.changeWeapon(mortar);
        }
        else if (event.key === '3') {
            this.changeWeapon(howitzer);
        }
        else if (event.key === '4') {
            this.changeWeapon(airstrike);
        }
        // else if (event.key === '1') { this.changeWeapon(sniper) }
    }
    updateCursorPosition(event) {
        let newMousePos = MouseHandler.updateMousePos(event);
        if (this.weapon.activeInstance) {
            let blast = this.weapon.activeInstance.blastRadElement;
            this.positionElem(blast, newMousePos);
        }
    }
    positionElem(elem, pos) {
        elem.style.left = pos.X - elem.offsetWidth / 2 + 'px';
        elem.style.top = pos.Y - elem.offsetHeight / 2 + 'px';
    }
    changeWeapon(wep) {
        this.weapon = wep;
        let inst = this.weapon.getAvailableInstance();
        if (inst) {
            this.weapon.switchBlastIndicatorStyle(false, inst);
        }
        this.switchCursor();
        this.updateCursorPosition();
        allWeaponTypes.forEach((x) => {
            if (x !== wep) {
                if (x.instances.length && x.activeInstance) {
                    if (x.activeInstance.ready != false) {
                        x.instances.forEach((inst) => { inst.blastRadElement.style.visibility = "hidden"; });
                    }
                }
            }
        });
    }
    switchCursor() {
        this.contentEl.classList.forEach((className) => {
            className.startsWith('cursor') ? this.contentEl.classList.remove(className) : "";
        });
        this.contentEl.classList.add(this.weapon.cursor);
    }
    newTarget() {
        let newTarget = new Target(this.contentEl);
        this.targets.push(newTarget);
    }
    start() {
        this.targetTimer = window.setInterval(() => {
            this.newTarget();
        }, 3000);
        this.gameTimer = window.setInterval(() => {
            this.targets.forEach((trg) => {
                trg.action();
            });
        }, 100);
    }
}
class MouseHandler {
    static mousePos = { X: '', Y: '' };
    static updateMousePos(event) {
        if (event) {
            this.mousePos.X = event.clientX;
            this.mousePos.Y = event.clientY;
        }
        return this.mousePos;
    }
}
class RandomNumberGen {
    static randomNumBetween(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}
var sniper;
var mortar;
var howitzer;
var airstrike;
var allWeaponTypes;
window.onload = () => {
    const contentEl = document.getElementById("content");
    sniper = new WeaponType(sniperInfo);
    mortar = new WeaponType(mortarInfo);
    howitzer = new WeaponType(howitzerInfo);
    airstrike = new WeaponType(airstrikeInfo);
    allWeaponTypes = [sniper, mortar, howitzer, airstrike];
    mortar.pushNewWeaponInstance();
    mortar.pushNewWeaponInstance();
    const game = new TargetHandler(contentEl);
    loadSound();
    game.start();
};
//# sourceMappingURL=app.js.map