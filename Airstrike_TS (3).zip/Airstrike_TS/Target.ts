﻿class Target {
    private contentEl: HTMLElement;
    private targetEl: HTMLElement;
    private picEl: HTMLImageElement;

    private speed: number;
    private picSource: string = assetsFolder + 'jeep.png';
    private destroyedSource: string = assetsFolder + 'fire.gif';
    private startPosition: number;
    public active: Boolean = true;

    constructor(contentEl: HTMLElement) {
        this.contentEl = contentEl; // ????? don't pass down?
        this.speed = getRandom(1, 8);
        this.startPosition = getRandom(10, 90);

        this.targetEl = document.createElement("div");
        this.picEl = document.createElement("img");
        this.picEl.src = this.picSource;
        this.targetEl.classList.add('target');
        this.targetEl.appendChild(this.picEl);
        this.targetEl.style.top = window.innerHeight * this.startPosition / 100 + 'px';
        this.targetEl.style.left = 0 + 'px';
        contentEl.appendChild(this.targetEl);
    }
    private move() {
        this.targetEl.style.left = parseInt(this.targetEl.style.left) + this.speed + "px";
    }
    public getTargetEl() {
        return this.targetEl;
    }

    public hit() {
        this.active = false;
        this.picEl.src = this.destroyedSource;
        this.picEl.classList.add('destroyed');
    }

    public action() {
        if (this.active == true) {

            this.move();
        }
    }
}
