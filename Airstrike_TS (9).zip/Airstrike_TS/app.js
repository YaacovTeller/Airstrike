class WeaponType {
    name;
    blastRadius;
    speed;
    blastPower;
    cursor;
    sound;
    cooldown;
    instances = [];
    activeInstance;
    explosionSource;
    imageSource;
    constructor(info) {
        this.name = info.name;
        this.blastRadius = info.blastRadius;
        this.blastPower = info.blastPower;
        this.speed = info.speed;
        this.cursor = info.cursor;
        this.sound = info.sound;
        this.cooldown = info.cooldown;
        this.explosionSource = info.explosionSource;
        this.imageSource = info.imageSource;
        this.pushNewWeaponInstance();
    }
    switchTo() {
        this.activeInstance = this.getAvailableInstance();
    }
    pushNewWeaponInstance() {
        let el = document.createElement('div');
        el.classList.add('blastRadius');
        el.classList.add('preFire');
        this.name == weaponNames.nuke ? el.classList.add('nukeIndicator') : "";
        el.classList.add('circle' + this.instances.length);
        el.style.width = el.style.height = this.blastRadius * 2 + 'px';
        el.style.visibility = "hidden";
        let explosion = document.createElement('img');
        explosion.classList.add('explosion');
        var timestamp = new Date().getTime();
        explosion.src = this.explosionSource + '?' + timestamp;
        addToContentEl(explosion);
        if (this.name == weaponNames.nuke) {
        }
        let inst = {
            ready: true,
            blastRadElement: el,
            explosion
        };
        this.instances.push(inst);
        addToContentEl(el);
    }
    getAvailableInstance() {
        let current = this.activeInstance;
        let nextReady = this.instances.find(inst => inst.ready == true) || null;
        if (nextReady != null) {
            nextReady.blastRadElement.style.visibility = "visible";
        }
        //    nextReady === current ? console.log("SAME!") : console.log("DIFF!")
        return nextReady;
    }
    fireFunc(targets) {
        if (this.activeInstance == null) {
            console.log("hit NULL inst");
            return;
        }
        let inst = this.activeInstance;
        let blastRadiusEl = inst.blastRadElement;
        this.prepFire(true, inst);
        let explosion = inst.explosion;
        let blastRect = blastRadiusEl.getBoundingClientRect();
        explosion.style.width = blastRect.width + 'px';
        explosion.style.height = blastRect.height + 'px';
        let blastCenter = CollisionDetection.getXYfromPoint(blastRadiusEl);
        explosion.style.left = blastCenter.X - explosion.clientWidth / 2 + 'px';
        explosion.style.top = blastCenter.Y - explosion.clientHeight * 0.9 + 'px';
        this.activeInstance = this.getAvailableInstance();
        setTimeout(() => {
            this.explosion_targetCheck(targets, inst);
            this.prepFire(false, inst);
            inst.ready = true;
            this.activeInstance = this.activeInstance == null ? this.getAvailableInstance() : this.activeInstance;
        }, this.speed);
    }
    explosion_targetCheck(targets, inst) {
        let explosion = inst.explosion;
        explosion.style.visibility = 'visible';
        setTimeout(() => {
            explosion.style.visibility = 'hidden';
        }, 1000);
        for (let target of targets) {
            let collisionInfo = CollisionDetection.checkPos(inst.blastRadElement, target.getTargetEl());
            if (collisionInfo) {
                let fraction = collisionInfo.dist / collisionInfo.radius;
                let severity;
                if (this.name === weaponNames.gun) {
                    severity = strikeSeverity.light;
                }
                else {
                    switch (true) {
                        case (fraction > 0.9):
                            severity = strikeSeverity.light;
                            break;
                        case (fraction <= 0.9 && fraction >= 0.5):
                            severity = strikeSeverity.medium;
                            break;
                        case (fraction < 0.5 && fraction >= 0.2):
                            severity = strikeSeverity.heavy;
                            break;
                        case (fraction < 0.2):
                            severity = strikeSeverity.catastrophic;
                            break;
                        default:
                            severity = strikeSeverity.light;
                    }
                }
                //   console.log("SEV: "+strikeSeverity[severity]);
                severity > strikeSeverity.light ? CollisionDetection.moveAtAngle(collisionInfo) : "";
                console.log("ANGLE: " + collisionInfo.angle);
                let angle = collisionInfo.angle;
                let direc;
                if (angle > 300 && angle < 360 || angle > 0 && angle < 60) {
                    direc = direction.forward;
                }
                else if (angle > 150 && angle < 210) {
                    direc = direction.backward;
                    console.log("DIREC: " + direction.backward);
                }
                //    if (angle > 330 && angle < 30) {
                //    direc = direction.forward
                //}
                //else if (angle > 150 && angle < 210) {
                //    direc = direction.backward
                //}
                if (target.damage != Damage.destroyed) {
                    target.hit(severity, direc);
                    this.bonusHitSound();
                }
            }
        }
    }
    prepFire(bool, inst) {
        this.switchBlastIndicatorStyle(bool, inst);
        if (bool) {
            this.rippleEffect(inst);
            RandomSoundGen.playNotSoRandomSound(this.sound);
            if (this.name == weaponNames.airstrike) {
                setTimeout(() => strike.play(), 2500);
            }
            if (this.name == weaponNames.nuke) {
                setTimeout(() => bigExpl.play(), 6500);
            }
        }
        inst.ready = !bool;
    }
    switchBlastIndicatorStyle(bool, inst) {
        if (inst == null)
            return;
        let blastRadiusEl = inst.blastRadElement;
        if (bool) {
            blastRadiusEl.classList.remove("preFire");
            blastRadiusEl.classList.add("firing");
        }
        else {
            blastRadiusEl.classList.add("preFire");
            blastRadiusEl.classList.remove("firing");
        }
    }
    rippleEffect(inst) {
        let blastRadiusEl = inst.blastRadElement;
        const circle = document.createElement("span");
        const diameter = blastRadiusEl.clientWidth;
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = blastRadiusEl.clientLeft + 'px';
        circle.style.top = blastRadiusEl.clientTop + 'px';
        circle.classList.add("ripple");
        const ripple = blastRadiusEl.getElementsByClassName("ripple")[0];
        ripple ? ripple.remove() : () => { };
        blastRadiusEl.appendChild(circle);
    }
    bonusHitSound() {
        RandomNumberGen.randomNumBetween(1, 8) == 8 ? pgia.play() : "";
    }
}
function addToContentEl(elem) {
    let contentEl = document.getElementById("content");
    contentEl.appendChild(elem);
}
function getRandom(low, high) {
    return Math.floor(Math.random() * high) + low;
}
class TargetHandler {
    targets = [];
    contentEl;
    hud = new HudHandler();
    targetTimer;
    gameTimer;
    weapon;
    constructor(element) {
        this.contentEl = element;
        this.contentEl.addEventListener("click", (event) => this.fireFunc());
        this.contentEl.addEventListener('mousemove', (event) => this.updateCursorPosition(event));
        window.addEventListener('keydown', (event) => this.handleKeyPress(event), true);
        this.hud.drawHUD();
        this.changeWeapon(mortar);
        this.weapon.switchBlastIndicatorStyle(false, null);
    }
    fireFunc() {
        this.weapon.fireFunc(this.targets);
    }
    handleKeyPress(event) {
        let int = parseInt(event.key);
        if (int && allWeaponTypes[int - 1]) {
            this.changeWeapon(allWeaponTypes[int - 1]);
        }
        else if (event.shiftKey && event.key === 'N') {
            this.addNuke();
        }
    }
    updateCursorPosition(event) {
        let newMousePos = MouseHandler.updateMousePos(event);
        if (this.weapon.activeInstance) {
            let blast = this.weapon.activeInstance.blastRadElement;
            this.positionElem(blast, newMousePos);
        }
    }
    positionElem(elem, pos) {
        elem.style.left = pos.X - elem.offsetWidth / 2 + 'px';
        elem.style.top = pos.Y - elem.offsetHeight / 2 + 'px';
    }
    changeWeapon(wep) {
        if (!allWeaponTypes.includes(wep))
            return;
        this.weapon = wep;
        this.weapon.switchTo();
        let inst = this.weapon.getAvailableInstance();
        if (inst) {
            this.weapon.switchBlastIndicatorStyle(false, inst);
        }
        this.switchCursor();
        this.updateCursorPosition();
        allWeaponTypes.forEach((x) => {
            if (x !== wep) {
                if (x.instances.length && x.activeInstance) {
                    if (x.activeInstance.ready != false) {
                        x.instances.forEach((inst) => { inst.blastRadElement.style.visibility = "hidden"; });
                    }
                }
            }
        });
        this.hud.selectBox(wep.name);
    }
    switchCursor() {
        this.contentEl.classList.forEach((className) => {
            className.startsWith('cursor') ? this.contentEl.classList.remove(className) : "";
        });
        this.contentEl.classList.add(this.weapon.cursor);
    }
    newTarget() {
        let newTarget = new Target(this.contentEl);
        this.targets.push(newTarget);
    }
    addNuke() {
        if (allWeaponTypes.includes(nuke))
            return;
        nuke = new WeaponType(nukeInfo);
        allWeaponTypes.push(nuke);
        this.hud.drawHUD();
    }
    start() {
        this.newTarget();
        this.targetTimer = window.setInterval(() => {
            this.newTarget();
        }, 3000);
        this.gameTimer = window.setInterval(() => {
            this.targets.forEach((trg) => {
                trg.action();
            });
        }, 100);
    }
}
class MouseHandler {
    static mousePos = { X: '', Y: '' };
    static updateMousePos(event) {
        if (event) {
            this.mousePos.X = event.clientX;
            this.mousePos.Y = event.clientY;
        }
        return this.mousePos;
    }
}
class RandomNumberGen {
    static randomNumBetween(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}
var sniper;
var mortar;
var howitzer;
var airstrike;
var nuke;
var allWeaponTypes;
var game;
window.onload = () => {
    const contentEl = document.getElementById("content");
    sniper = new WeaponType(sniperInfo);
    mortar = new WeaponType(mortarInfo);
    howitzer = new WeaponType(howitzerInfo);
    airstrike = new WeaponType(airstrikeInfo);
    allWeaponTypes = [sniper, mortar, howitzer, airstrike];
    mortar.pushNewWeaponInstance();
    mortar.pushNewWeaponInstance();
    game = new TargetHandler(contentEl);
    loadSound();
    game.start();
};
//function throw1 (left, top, img){
//    let randomLeftRight = RandomNumberGen.randomNumBetween(0, 1)
//    let randomHeight = RandomNumberGen.randomNumBetween(20, 80)
//    let randomDistance = RandomNumberGen.randomNumBetween(20, 80)
//    $(img).css({ fontSize: 0 }).animate({
//        fontSize: 45
//    }, {
//        duration: 300,
//        easing: "linear",
//        step: function (t, fx) {
//            var a = t / 15;
//            var x = randomLeftRight == 1 ? left - Math.cos(a) * randomDistance : left + Math.cos(a) * randomDistance;
//            var y = top - Math.sin(a) * randomHeight;
//            $(this).css({ left: x, top: y });
//        }
//    });
//}
//# sourceMappingURL=app.js.map