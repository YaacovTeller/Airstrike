﻿class HudHandler {
    private hud: HTMLElement
    private selectedWep: Element
    private scoreBox: HTMLElement
    private kills: number

    public drawHUD() {
        let hud = document.getElementById('hud');
        if (hud) hud.remove();

        let el = document.createElement('div')
        el.classList.add("hud")
        el.id = 'hud';
        addToContentEl(el)
        this.hud = el;

        for (let x in allWeaponTypes) {
            let wep = allWeaponTypes[x]
            let wepBox = document.createElement('div');
            let num = document.createElement('span');
            num.className = "wepNum";
            num.innerText = (parseInt(x) + 1).toString();
            wepBox.appendChild(num);
            wepBox.classList.add("wepBox");
            wepBox.dataset.name = wep.name;
            wepBox.style.backgroundImage = "url(" + wep.imageSource + ")";
            wepBox.onclick = (event) => { game.changeWeapon(wep); event.stopPropagation() }
            el.appendChild(wepBox);
            for (let y of wep.instances) {
                let instBox = document.createElement('div');
                instBox.classList.add("instBox");
                wepBox.appendChild(instBox);
            }
        }
        this.drawScore();
    }
    public drawScore() {
        this.scoreBox = document.createElement('div');
        this.scoreBox.classList.add('score');
        this.updateScore();
    }
    public updateScore() {
        this.scoreBox.innerText = this.kills + "";
    }
    public selectBox(wepName: string) {
        let weps: HTMLCollectionOf<Element> = this.hud.getElementsByClassName('wepBox');
        for (let x of weps) {
            if (x.getAttribute('data-name') == wepName) {
                x.classList.add("selected")
                this.selectedWep = x;
            }
            else x.classList.remove("selected");
        }
    }
    public selectInst() {
        let insts = this.selectedWep.getElementsByClassName('instBox');
        for (let x of insts) {

        }
    }
}