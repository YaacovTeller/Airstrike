var Status;
(function (Status) {
    Status[Status["active"] = 0] = "active";
    Status[Status["disabled"] = 1] = "disabled";
})(Status || (Status = {}));
var Damage;
(function (Damage) {
    Damage[Damage["undamaged"] = 0] = "undamaged";
    Damage[Damage["damaged"] = 1] = "damaged";
    Damage[Damage["badDamaged"] = 2] = "badDamaged";
    Damage[Damage["destroyed"] = 3] = "destroyed";
})(Damage || (Damage = {}));
class Target {
    targetEl;
    picEl;
    damageEl;
    speed;
    picSource = assetsFolder + 'jeep.png';
    destroyedSource = assetsFolder + 'fire_3.gif';
    damagedSource = assetsFolder + 'smoke_3.gif';
    badDamagedSource = assetsFolder + 'fire_1.gif';
    startPosition;
    status = Status.active;
    damage = Damage.undamaged;
    constructor(contentEl) {
        this.speed = getRandom(1, 8);
        this.startPosition = getRandom(10, 90);
        this.targetEl = document.createElement("div");
        this.picEl = document.createElement("img");
        this.picEl.src = this.picSource;
        this.damageEl = document.createElement("img");
        this.targetEl.classList.add('target');
        this.targetEl.appendChild(this.picEl);
        this.targetEl.appendChild(this.damageEl);
        this.targetEl.style.top = window.innerHeight * this.startPosition / 100 + 'px';
        this.targetEl.style.left = 0 + 'px';
        contentEl.appendChild(this.targetEl);
    }
    move() {
        this.targetEl.style.left = parseInt(this.targetEl.style.left) + this.speed + "px";
    }
    getTargetEl() {
        return this.targetEl;
    }
    hit(sev) {
        if (sev > strikeSeverity.light) {
            this.status = Status.disabled;
        }
        else {
            setTimeout(() => this.status = Status.disabled, 1000);
        }
        if (sev == strikeSeverity.light) {
            this.damage != Damage.undamaged ? sev = strikeSeverity.medium : "";
            this.damage = Damage.damaged;
            this.damageEl.src = this.damagedSource;
            this.damageEl.classList.add('lightDamaged');
            // MOVE
        }
        if (sev == strikeSeverity.medium) {
            this.damage = Damage.badDamaged;
            this.damageEl.src = this.badDamagedSource;
            this.damageEl.classList.add('badDamaged');
            this.damageEl.classList.remove('lightDamaged');
        }
        if (sev == strikeSeverity.heavy) {
            this.damage = Damage.destroyed;
            this.damageEl.src = this.badDamagedSource;
            this.damageEl.classList.add('badDamaged');
            this.damageEl.classList.remove('lightDamaged');
        }
        if (sev == strikeSeverity.catastrophic) {
            this.damage = Damage.destroyed;
            this.picEl.src = this.destroyedSource;
            this.picEl.classList.add('destroyed');
            this.damageEl.style.visibility = "hidden";
        }
    }
    action() {
        if (this.status == Status.active) {
            this.move();
        }
    }
}
//# sourceMappingURL=target.js.map